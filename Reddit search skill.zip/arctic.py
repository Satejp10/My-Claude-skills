#!/usr/bin/env python3
"""
Arctic Shift CLI. Reddit retrieval that survives the known traps.

  arctic.py post <post_id> [--comments N]
  arctic.py url  "<reddit.com/.../comments/... url>" [--comments N]
  arctic.py sub  <subreddit> [--days N] [--limit N]
  arctic.py search <subreddit> <keyword> [--days N] [--limit N]

Every command prints JSON with an "_engagement" block. Read it before
quoting any number: Arctic Shift's score/num_comments fields are archive
snapshots taken at post creation and are usually wrong.

Stdlib only. No install step.
"""

import argparse
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

BASE = "https://arctic-shift.photon-reddit.com/api"
# Required. The default urllib agent gets HTTP 403 from Arctic Shift.
UA = "reddit-research-skill/1.0 (personal research; contact via github.com/Satejp10)"

RETRYABLE = ("timeout", "slow down", "internal server error", "maintenance", "try again")
# NB: 'permalink' and 'upvote_ratio' are NOT valid fields= values (HTTP 400),
# even though they appear in the full object when fields= is omitted. Use 'url'.
POST_FIELDS = "id,title,selftext,author,subreddit,created_utc,url,score,num_comments,link_flair_text"
COMMENT_FIELDS = "id,body,author,score,created_utc,parent_id"


def get(path, params, tries=4):
    """GET with retries. Arctic Shift puts errors in the body at HTTP 200."""
    url = f"{BASE}/{path}?" + urllib.parse.urlencode(
        {k: v for k, v in params.items() if v not in (None, "")}
    )
    last = None
    for attempt in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=60) as r:
                raw = r.read().decode("utf-8", errors="replace")
            # strict=False: comment bodies contain raw control characters
            payload = json.loads(raw, strict=False)
        except urllib.error.HTTPError as e:
            last = f"HTTP {e.code}"
            if e.code in (429, 500, 502, 503, 504):
                time.sleep(2 ** attempt + 1)
                continue
            raise SystemExit(f"arctic: {last} on {url}")
        except Exception as e:
            last = str(e)
            time.sleep(2 ** attempt + 1)
            continue

        err = payload.get("error")
        if err:
            last = str(err)
            if any(m in last.lower() for m in RETRYABLE):
                time.sleep(2 ** attempt + 1)
                continue
            raise SystemExit(f"arctic: API error: {last}")

        # 'data' can be present-but-null. .get('data', []) would return None here.
        return payload.get("data") or []

    raise SystemExit(
        f"arctic: gave up after {tries} tries. Last: {last}\n"
        "If this is a broad text scan, narrow it with --days or drop to a "
        "subreddit listing and filter locally."
    )


def post_id_from_url(u):
    m = re.search(r"/comments/([a-z0-9]+)", u, re.I)
    if not m:
        m = re.search(r"^(?:t3_)?([a-z0-9]{5,8})$", u.strip(), re.I)
    if not m:
        raise SystemExit(f"arctic: no post id found in {u!r}")
    return m.group(1)


def enrich(posts, trunc):
    """Fix two things the raw API gets wrong for downstream use.

    - 'url' is the LINK TARGET, not the thread. For a link post it points at
      github.com / i.redd.it / medium.com, so it cannot be used as a permalink.
      Build the thread URL from subreddit + id instead.
    - selftext is unbounded. Forty posts of full bodies is ~8k tokens of
      context for one search. Truncate by default.
    """
    removed = 0
    for p in posts:
        if p.get("subreddit") and p.get("id"):
            p["reddit_url"] = f"https://www.reddit.com/r/{p['subreddit']}/comments/{p['id']}/"
        body = p.get("selftext")
        if body == "[removed]":
            removed += 1
        elif body and trunc and len(body) > trunc:
            p["selftext"] = body[:trunc] + f"... [truncated, {len(body)} chars total; --full for all]"
    return removed


def coverage_note(items, days_requested):
    """Expose the gap between the window asked for and the window actually returned.

    sort=desc + limit=N returns the N NEWEST posts in the window, which on a
    busy subreddit can be a few hours out of a 90-day request. Without this,
    that reads as a representative sample of the whole period. It isn't.
    """
    ts = [i.get("created_utc") for i in items if i.get("created_utc")]
    if not ts:
        return {"covered": "none"}
    lo, hi = min(ts), max(ts)
    span = (hi - lo) / 86400.0
    note = {
        "oldest": time.strftime("%Y-%m-%d %H:%M", time.gmtime(lo)),
        "newest": time.strftime("%Y-%m-%d %H:%M", time.gmtime(hi)),
        "span_days": round(span, 2),
        "days_requested": days_requested,
    }
    if days_requested and span < days_requested * 0.5:
        note["warning"] = (
            f"Hit the limit before reaching back {days_requested} days. These are "
            f"the newest {len(items)} posts only, covering {round(span,2)} days. "
            "This is NOT a representative sample of the requested window. To cover "
            "the full period, page backwards with --days on smaller slices."
        )
    return note


def engagement_note(items, kind, real_count=None):
    """State plainly whether the numbers can be trusted.

    Discriminator: a fresh-ingest snapshot has NO variance - every score is
    exactly 1, because that is the value at post creation. Real backfilled
    data always has spread, even when most comments legitimately sit at 0/1.

    Do not use "what fraction are 0 or 1" - on a large real thread that is
    ~70%, which is just the normal Reddit long tail, and it wrongly flags
    good data as bad.
    """
    scores = [i.get("score") for i in items if i.get("score") is not None]
    if not scores:
        return {"scores_present": 0, "score_status": "absent"}

    distinct, hi = len(set(scores)), max(scores)
    note = {
        "scores_present": len(scores),
        "distinct_values": distinct,
        "max_score": hi,
    }

    if distinct <= 2 and hi <= 1:
        note["score_status"] = "SNAPSHOT_NOT_REAL"
        note["score_trustworthy"] = False
        note["warning"] = (
            f"Every {kind} score is 0 or 1 with no variance. This is the archive "
            "snapshot taken at creation, NOT real upvote counts. Do not rank by "
            "score or report these as upvotes. Use comment volume instead, or "
            "Apify for live scores."
        )
    elif len(scores) < 5 and hi <= 2:
        note["score_status"] = "INDETERMINATE"
        note["score_trustworthy"] = False
        note["warning"] = (
            f"Only {len(scores)} {kind}(s) with low scores - cannot tell a real "
            "low-engagement thread from an un-backfilled snapshot. Do not quote "
            "these numbers as upvotes."
        )
    else:
        note["score_status"] = "BACKFILLED"
        note["score_trustworthy"] = True

    if real_count is not None:
        note["actual_comments_retrieved"] = real_count
        note["use_this_not_num_comments"] = True
    return note


def cmd_post(pid, n, trunc=1500):
    posts = get("posts/ids", {"ids": pid, "fields": POST_FIELDS})
    if not posts:
        raise SystemExit(
            f"arctic: post {pid} not in the archive. If it is brand new, the "
            "archive may not have ingested it yet - use Apify."
        )
    p = posts[0]
    enrich(posts, trunc)
    comments = []
    seen, before = set(), None
    while len(comments) < n:
        batch = get(
            "comments/search",
            {
                "link_id": f"t3_{pid}",
                "limit": min(100, n - len(comments)),
                "sort": "desc",
                "before": before,
                "fields": COMMENT_FIELDS,
            },
        )
        if not batch:
            break
        fresh = [c for c in batch if c["id"] not in seen]
        if not fresh:
            break
        seen.update(c["id"] for c in fresh)
        comments.extend(fresh)
        before = min(c["created_utc"] for c in batch)
        time.sleep(0.4)

    comments.sort(key=lambda c: c.get("score") or 0, reverse=True)
    return {
        "post": p,
        "comment_count_actual": len(comments),
        "comments": comments,
        "_engagement": engagement_note(comments, "comment", real_count=len(comments)),
        "_note": ("Post body is [removed] by a moderator - the comments below "
                  "usually survive and still carry the discussion."
                  if p.get("selftext") == "[removed]" else None),
    }


def cmd_list(sub, days, limit, keyword=None, trunc=500):
    params = {
        "subreddit": sub,
        "limit": min(100, limit),
        "sort": "desc",
        "fields": POST_FIELDS,
    }
    if days:
        params["after"] = int(time.time()) - days * 86400
    if keyword:
        params["title"] = keyword
    posts = get("posts/search", params)
    if not posts:
        return {
            "subreddit": sub,
            "keyword": keyword,
            "returned": 0,
            "posts": [],
            "_note": (
                "No results. Check the subreddit spelling (Arctic Shift returns an "
                "empty list, not an error, for a subreddit that does not exist), "
                "widen --days, or drop the keyword - `title=` is substring matching, "
                "not semantic search."
            ),
        }
    removed = enrich(posts, trunc)
    return {
        "subreddit": sub,
        "keyword": keyword,
        "returned": len(posts),
        "mod_removed_bodies": removed,
        "posts": posts,
        "_coverage": coverage_note(posts, days),
        "_engagement": engagement_note(posts, "post"),
        "_note": "Sorted by date. Arctic Shift cannot sort by score - use Apify for top-by-score.",
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)

    a = sp.add_parser("post"); a.add_argument("post_id"); a.add_argument("--comments", type=int, default=200)
    b = sp.add_parser("url"); b.add_argument("url"); b.add_argument("--comments", type=int, default=200)
    c = sp.add_parser("sub"); c.add_argument("subreddit"); c.add_argument("--days", type=int, default=7); c.add_argument("--limit", type=int, default=50)
    d = sp.add_parser("search"); d.add_argument("subreddit"); d.add_argument("keyword"); d.add_argument("--days", type=int, default=90); d.add_argument("--limit", type=int, default=50)

    for sub_p in (a, b, c, d):
        sub_p.add_argument("--full", action="store_true",
                           help="do not truncate selftext (costs a lot of context)")

    args = ap.parse_args()
    trunc = 0 if args.full else None
    if args.cmd == "post":
        out = cmd_post(args.post_id, args.comments, trunc if trunc is not None else 1500)
    elif args.cmd == "url":
        out = cmd_post(post_id_from_url(args.url), args.comments, trunc if trunc is not None else 1500)
    elif args.cmd == "sub":
        out = cmd_list(args.subreddit, args.days, args.limit, None, trunc if trunc is not None else 500)
    else:
        out = cmd_list(args.subreddit, args.days, args.limit, args.keyword, trunc if trunc is not None else 500)

    json.dump(out, sys.stdout, indent=2, ensure_ascii=False)
    print()


if __name__ == "__main__":
    main()
