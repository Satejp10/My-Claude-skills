---
name: reddit-research
description: Retrieve Reddit posts, comment threads, and subreddit activity when reddit.com itself is blocked. Use whenever a task involves Reddit content - a reddit.com URL is pasted, the user asks what people on Reddit are saying about something, asks to check a subreddit, wants community reactions or sentiment on a product/model/tool, references a thread or post ID, or asks to pull comments from a discussion. Also use when a previous attempt to reach Reddit failed or returned an empty page. Covers the Arctic Shift archive API, the discovery-then-retrieval workflow, the Apify live-scrape fallback, and the engagement-score traps that silently produce wrong answers.
---

# Reddit Research

reddit.com is blocked at the egress proxy. Not just `web_fetch` - `curl` from
bash gets `403 Blocked by egress policy` too. There is no user-agent or mirror
trick that gets around it. Retrieval goes through the **Arctic Shift archive API**.

## The one rule that matters most

**Arctic Shift `score` and `num_comments` start as placeholders and are only
sometimes backfilled.**

The archive snapshots a post seconds after creation, when both fields are `1`.
A backfill pass runs later, but it is delayed and does not reach everything.
Verified: a post reporting `num_comments: 1` had 70 archived comments.

**How to tell real data from a placeholder** - look at the *spread*, not the
average. A fresh snapshot has zero variance: every score is exactly 1. Real
data always has spread, even when most comments legitimately sit at 0 or 1.

| Signal | Meaning |
|---|---|
| `distinct_values == 1`, `max == 1` | Placeholder. Not real numbers. |
| `max > 2`, several distinct values | Backfill ran. Numbers are usable. |
| Fewer than 5 items, all low | Indeterminate. Don't quote. |

Do **not** use "what fraction are 0 or 1" as the test. On a real 400-comment
thread that fraction is ~71%, which is just the normal Reddit long tail. That
heuristic flags good data as bad.

The bundled script computes this for you and returns `score_status` as
`SNAPSHOT_NOT_REAL`, `BACKFILLED`, or `INDETERMINATE`. Trust that field.

Consequences:

- **Never** present `num_comments` as the comment count. Fetch the comments and
  count them. The script returns `comment_count_actual`.
- If `score_status` is not `BACKFILLED`, say engagement numbers are unavailable
  rather than reporting 1. Real live numbers require Apify.
- Backfill can land *mid-session*. A post that showed all-1s an hour ago may
  show real scores now. Re-check rather than caching a verdict.

Comment *bodies* are archived faithfully regardless of age. Only the numeric
fields are affected.

## Workflow: discovery, then retrieval

These are separate jobs and different tools do them.

Arctic Shift is a **filter engine**, not a search engine. It answers
`WHERE subreddit=X AND title~kw ORDER BY date`. It has no relevance ranking, so
it is bad at "find the thread about X" and excellent at "give me everything from
this subreddit / this post ID".

| Starting point | Route |
|---|---|
| User pasted a reddit.com URL | Extract the base36 ID after `/comments/`, retrieve directly. Skip discovery. |
| Open-ended, subreddit known | **Go straight to Arctic Shift `search`.** Its `title=` substring match is good and costs one call. |
| Open-ended, subreddit unknown | `web_search` for `X reddit`, pull IDs from any reddit.com URLs, retrieve via Arctic Shift. Be warned: web_search frequently returns **zero** reddit.com results even for obviously Reddit-heavy topics, preferring docs sites and HN. If it does, guess the subreddit and use Arctic Shift search instead. |
| Known subreddit, want recent activity | Straight to Arctic Shift, enumerate by date, filter locally. |
| Need real upvote counts or "top of all time" | Arctic Shift cannot do this. Go to Apify. |
| Thread is under a few hours old | Arctic Shift may not have ingested it. Go to Apify. |

`site:reddit.com` in web_search under-returns. Appending `reddit` to the query
works better, but still often yields nothing. Arctic Shift's own keyword search
is the more reliable discovery path whenever you can name the subreddit.

## Quick start

Use the bundled script. It handles the user-agent, retries, lenient parsing, and
the engagement guard.

```bash
python3 scripts/arctic.py post <post_id>          # post + all comments, ranked
python3 scripts/arctic.py sub <subreddit> --days 7 --limit 50
python3 scripts/arctic.py search <subreddit> <keyword> --days 90
python3 scripts/arctic.py url "<any reddit.com/comments/... url>"
```

Add `--full` to disable selftext truncation. Don't, unless you need the bodies:
truncation cuts output ~28% and forty full post bodies is several thousand
tokens.

Every response carries three blocks worth reading before you write anything:

- `_engagement` - whether score numbers are real. See the rule above.
- `_coverage` - **the window actually returned vs the window requested.** With
  `sort=desc`, `--days 90 --limit 60` on a busy subreddit returns the 60
  *newest* posts, which can be five hours, not ninety days. The script warns
  when the gap is large. Never describe a truncated pull as a period sample.
- `mod_removed_bodies` - how many `selftext` fields are `[removed]`. This runs
  ~35% on active subreddits. The comments usually survive and still carry the
  discussion, so a removed body is not a dead thread.

Use the computed `reddit_url` field for links, **never** the raw `url` field.
`url` is the post's link *target*, so on link posts it points at github.com or
i.redd.it, not at the thread.

For anything the script doesn't cover, `reference/endpoints.md` has the raw API
surface. Always `curl`, never `web_fetch`.

## Escalation ladder

1. **Arctic Shift** - default. Free, no auth, 2005 to present, full comment
   trees. Cannot give current scores.
2. **Apify** (`trudax/reddit-scraper-lite`) - only when live scores, top-by-score
   listings, or sub-6-hour content are genuinely required. Costs money and takes
   a minute. Pass **direct post URLs** as `startUrls` with `skipComments: false`,
   `skipUserPosts: true`, proxy enabled. Subreddit-listing URLs crash this actor.
3. **Stop and say so.** If both fail, report exactly what was tried. Do not
   substitute press coverage or a blog summarizing the thread and present it as
   the Reddit content.

## Never do these

- `web_fetch` on reddit.com, old.reddit.com, `arctic-shift.photon-reddit.com/search`,
  or `ihsoyct.github.io`. The last two are client-rendered JS shells that return
  an empty page to every tool. They work in a human browser only.
- Python `urllib` or `requests` with default headers. Arctic Shift returns
  **403** to the default urllib agent. Set a User-Agent.
- Trust an HTTP 200 from Arctic Shift. Errors arrive in the response body with a
  200 status.
- Report `score: 1` as a real upvote count.

`reference/failure-modes.md` has the full tested matrix of what works, what
doesn't, and every parsing trap. Read it if anything behaves unexpectedly.
