# Failure Modes and Tested Access Matrix

Everything here was tested empirically, not assumed. Dates note when.

## Access matrix

### Works

| Route | Notes |
|---|---|
| Arctic Shift `/api/...` via `curl` | Primary. HTTP 200, real data. Confirmed 2026-06-11 and 2026-08-01. |
| Arctic Shift `/api/...` via python **with a User-Agent header** | Works. Without one, 403. |
| Arctic Shift `title=` keyword search | Substring match on titles, works well, one call. **Preferred discovery route when the subreddit is known.** |
| `web_search` for thread discovery | Has relevance ranking, but frequently returns **zero** reddit.com URLs even on Reddit-heavy topics - it prefers vendor docs, aggregators and HN. Verified failure on a query about a widely-discussed model limitation, where Arctic Shift's own keyword search found 22 relevant threads for the same topic. Use it only when the subreddit is unknown. |
| Apify `trudax/reddit-scraper-lite` | Direct post URLs as `startUrls`, `skipComments: false`, `skipUserPosts: true`, `skipCommunity: true`, proxy enabled. Returns live scores. |
| Apify `harshmaur/reddit-scraper` | `searchTerms` as an array, `searchSort: relevance`, `scrapeComments` paired with `maxCommentsPerPost`. Returned 555 items in one run. |

### Does not work

| Route | Failure | Tested |
|---|---|---|
| `web_fetch` on reddit.com | Blocked | ongoing |
| **`curl` on reddit.com / old.reddit.com** | `403 Blocked by egress policy`. Blocked at the proxy layer, not the tool layer. No UA or header trick works. | 2026-08-01 |
| reddit.com `.json` API | Same egress block. Also deprecated publicly. | 2026-08-01 |
| reddit.com `.rss` feeds | Same egress block. | 2026-08-01 |
| `arctic-shift.photon-reddit.com/search` | Client-rendered JS shell. Returns an empty page. **This URL was in the user's custom instructions and caused a full run to fail, then falsely declare Reddit inaccessible.** | 2026-07-24 |
| `ihsoyct.github.io/index.html?comments=<id>&backend=artic_shift` | Same. 2,084 bytes of empty shell. Works in a human browser only. | 2026-08-01 |
| PullPush API (`api.pullpush.io`) | Dead connection. Pushshift's other successor; do not rely on it. | 2026-06-11 |
| redlib / libreddit public instances | Scanned 8 instances: all 403, 503, timeout, or Anubis proof-of-work challenge pages. `safereddit.com` returns HTTP 200 but the body is a browser-verification page. | 2026-08-01 |
| Apify generic RAG web browser on reddit URLs | Hits Reddit's bot wall. Titles come through, bodies don't. old.reddit.com through it also failed. | 2026-07-01 |
| Apify `fatihtahta/reddit-scraper-search-fast` | Reports SUCCEEDED with **0 items**. Never trust the run status; always check the dataset item count. | 2026-06-15, 2026-07-07 |
| Apify `trudax/reddit-scraper-lite` in listing mode | Crashes instantly when given `/r/x/top/?t=day` as a startUrl. Direct post URLs only. | 2026-06-15 |

## Parsing and error traps

### HTTP 200 with the error in the body
```json
{"data": null, "error": "Internal server error"}
```
Status code is 200. The status tells you nothing. Check `error` and check that
`data` is a list.

### `dict.get('data', [])` returns None
The default only fires when the key is **absent**. Here the key exists with a
`null` value, so you get `None` and `len(None)` throws TypeError. This crashed a
live session.

```python
items = payload.get("data") or []   # correct
```

### Strict JSON parsing breaks on comment bodies
Reddit comment bodies contain raw control characters. Use `strict=False`:

```python
json.loads(text, strict=False)
```

### Throttle looks like an error
```json
{"error": "Timeout. Maybe slow down a bit"}
```
This is rate limiting, **not** a failure. Sleep a few seconds and retry. Do not
report it as "Arctic Shift is down".

### Broad text scans time out
`selftext=` searches across the full index will 500 or time out. Fixes, in order:
1. Add or tighten `after=`.
2. Narrow to a specific subreddit.
3. Give up on server-side text search: pull a date-bounded subreddit listing and
   filter locally in python.

### The 200-comment ceiling
`/api/comments/tree?limit=200` caps total comments returned. Large threads are
sampled. Either paginate `/api/comments/search` or state that coverage is partial.

### Service outages
Arctic Shift is a free single-maintainer service. It went down for maintenance
on 2026-07-07. If everything returns errors, check whether the base URL responds
at all before debugging your query.

## The engagement data problem

Measured on r/ClaudeAI, 2026-08-01, sampling 5 posts per bucket:

| Post age | `score` values | `num_comments` values |
|---|---|---|
| 1 day | 1, 1, 1, 1, 1 | 1, 1, 1, 0, 1 |
| 4 days | 1, 1, 0, 0, 4 | 12, 2, 5, 7, 105 |
| 2 weeks | 1, 1, 276, 1, 2 | 3, 2, 52, 2, 1 |
| 8 months | 0, 36, 1, 1, 1 | 2, 43, 2, 2, 1 |

Reading: the archive ingests at post creation, when score and comment count are
both 1. A backfill pass runs later but hits only a minority of posts. Even
8-month-old posts are mostly still pinned at 1.

Comment *scores* follow the same pattern. On a 1-day-old post every comment
scored 1; on a 2-week-old post comment scores were real (45, 31, 14, 13).

### Why the obvious heuristic is wrong

"Flag it if most scores are 0 or 1" seems right and is not. Measured:

| Thread | n | max | distinct values | fraction at 0/1 | truth |
|---|---|---|---|---|---|
| fresh, 2 days | 70 | 1 | **1** | 100% | placeholder |
| large, 2 months | 400 | 46 | **24** | 71% | real data |
| medium, 2 weeks | 53 | 45 | **18** | 38% | real data |

The 400-comment thread has 71% of comments at 0/1 and is completely real - that
is just Reddit's comment-score long tail. Fraction-based tests flag it as fake.

**Use variance, not average.** A placeholder set has exactly one distinct value.
Real data always has spread. Test: `distinct_values <= 2 and max <= 1`.

### Backfill can land mid-session

Post `1vbkq6o` returned 70 comments all scored 1 in the morning, and 79 comments
with `max_score: 114` a few hours later. Do not cache a trustworthiness verdict
across a long session - re-run and re-check.

**Reliable engagement proxy:** fetch the comments and count them. Post
`1vbkq6o` reported `num_comments: 1`; `/api/comments/search` returned 66. Comment
volume is available immediately and correlates with attention. Use it instead of
score, and label it as comment volume, not upvotes.

If the task genuinely requires upvote counts, that is an Apify job. Say so
rather than reporting 1.
