# Arctic Shift API Reference

Base: `https://arctic-shift.photon-reddit.com`

No auth, no key, no rate-limit sign-up. Free community service run by
ArthurHeitmann (github.com/ArthurHeitmann/arctic_shift). Be polite: low limits,
sleep between calls, respect the rate-limit response headers.

**Always send a User-Agent.** The default python-urllib agent gets HTTP 403.
`curl` sends its own agent and works out of the box.

## Fullname prefixes

Reddit's internal type prefixes. Getting these wrong returns empty data, not an
error.

| Prefix | Type | Used in |
|---|---|---|
| `t1_` | comment | `parent_id` |
| `t3_` | post | `link_id` |
| `t5_` | subreddit | rarely needed |

A post ID from a URL (`/r/X/comments/1vbkq6o/title/`) is bare base36: `1vbkq6o`.
The `/api/posts/ids` endpoint wants it **bare**. The comment endpoints want it
**prefixed**: `t3_1vbkq6o`.

## Endpoints

### Posts by ID
```
/api/posts/ids?ids=<id>[,<id2>,...]
```
Bare IDs, comma-separated. The most reliable endpoint. Use this after
discovering a thread via web_search.

### Post search
```
/api/posts/search?subreddit=<sub>&limit=<n>&sort=desc
    &after=<unix|YYYY-MM-DD>&before=<unix|YYYY-MM-DD>
    &title=<keyword>&selftext=<keyword>&author=<user>
    &fields=id,title,selftext,created_utc,author,permalink
```
- `sort` is by **date only**. There is no sort-by-score. This is why "top posts"
  requires Apify.
- `limit` max is 100.
- Always pass `after=`. Unbounded scans across the full index time out.
- `title=` does substring matching on titles. `selftext=` scans bodies and is
  much slower - it is the endpoint most likely to return a 500.
- `fields=` trims the response at the API level. Use it. Full post objects are
  ~2.8KB each and mostly Reddit boilerplate you don't need.

### Comment search
```
/api/comments/search?link_id=t3_<postid>&limit=<n>&sort=desc
    &subreddit=<sub>&author=<user>&body=<keyword>
    &fields=id,body,score,created_utc,author,parent_id
```
Flat list of comments for a post. Simpler than the tree and usually what you
want. `limit` max 100; paginate with `after=` on `created_utc` for more.

### Comment tree
```
/api/comments/tree?link_id=t3_<postid>&limit=200&md2html=false
```
- Nested structure. Replies live at `data.replies.data.children`, **not** a flat
  list. Requires recursive traversal.
- `limit=200` is a hard ceiling on total returned comments. A 600-comment thread
  is **sampled, not retrieved**. Say so if characterizing coverage.
- Keep `md2html=false`. HTML conversion bloats the payload for no benefit.
- Node types: `kind: "t1"` is a comment, `kind: "more"` is a truncation stub.

### Aggregations
```
/api/posts/aggregate?subreddit=<sub>&after=<date>&aggregate=created_utc&frequency=day
```
Post volume over time without pulling the posts. Cheap way to spot activity
spikes. Also works on `/api/comments/aggregate`.

### Subreddit and user metadata
```
/api/subreddits/search?subreddit_prefix=<prefix>&limit=<n>
/api/subreddits/search?min_subscribers=<n>&max_subscribers=<n>
/api/users/ids?ids=<username>
```
Subreddit search is **name/prefix based**, not topical. It cannot answer "find
subreddits about woodworking". Subscriber counts here are also archive
snapshots and drift.

## The `fields=` trap

Not every key present in a full response object is a legal `fields=` value. Two
common ones are rejected with **HTTP 400** and `"'X' is not a valid field"`:

| Wanted | Status | Use instead |
|---|---|---|
| `permalink` | rejected | build it yourself, see below |
| `upvote_ratio` | rejected | nothing; it's unreliable anyway |

Verified-good post fields: `id, title, selftext, author, subreddit, created_utc,
url, score, num_comments, link_flair_text`

Verified-good comment fields: `id, body, author, score, created_utc, parent_id,
link_id`

If a `fields=` request 400s, bisect one field at a time rather than abandoning
the parameter. Dropping `fields=` entirely works but costs ~2.8KB per post.

### `url` is not a permalink

`url` is the post's link *target*. On a self-post it happens to equal the thread
URL; on a link post it is github.com, i.redd.it, medium.com, or wherever the OP
linked. It cannot be used to link back to the discussion.

Construct the thread URL instead:

```
https://www.reddit.com/r/{subreddit}/comments/{id}/
```

Note: `selftext` returns `"[removed]"` for moderator-removed posts - about 35%
of posts on an active subreddit in one measured sample. The comments almost
always survive, so a removed body is not a dead thread.

### The limit-vs-window trap

`sort=desc` returns the NEWEST `limit` posts inside the window. On a busy
subreddit, `after=90 days ago` with `limit=60` returns roughly five *hours* of
posts, because 60 posts is less than one day of volume. Measured: 0.21 days
returned against a 90-day request.

Nothing in the response signals this. Always compute the actual min/max
`created_utc` of what came back and compare it to what you asked for. To truly
cover a long window, page backwards in slices with `before=`.

## Date parameters

`after` and `before` accept unix seconds or `YYYY-MM-DD`. Unix is safer, no
timezone ambiguity.

```bash
AFTER=$(date -d '30 days ago' +%s)
```

## Pagination

Cursor on time, not offset. Take the oldest `created_utc` from the batch and
pass it as the next `before`, walking backwards. There is no page token.

## Response envelope

```json
{"data": [ ... ], "error": null}
```

`data` is `null` (not `[]`) on error. See failure-modes.md - this specific
detail causes a TypeError that has crashed a session before.
