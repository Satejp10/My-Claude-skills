---
name: design-reference-analyst
description: Audit websites the user has saved as design inspiration. Extract each site's design philosophy, visual language, layout patterns, motion techniques, and tech-stack signals, cluster the set into design movements, recommend similar sites, and produce a "steal-this" checklist of transferable techniques. Trigger whenever the user shares 2+ URLs as design inspiration, asks "what's the design philosophy of these sites", says they "saved these as references", wants a moodboard or design audit, asks how to find more sites in the same style, mentions building a landing page / marketing site / product page and references sites they like, asks about web design trends (AI-native minimalism, brutalist editorial, scrollytelling, bento grids, glassmorphism), wants tech-stack inferences (Framer / Webflow / Next.js / Gatsby), or wants curated galleries, GitHub awesome lists, or CodePen creators in a design lane. Trigger even without the word "audit" — any web-design reference research counts.
---

# Design Reference Analyst

Take a list of design-reference URLs the user has saved and produce a structured audit: per-site breakdown, cross-cutting themes, similar-site recommendations grouped by philosophy, curated discovery resources, and a "steal-this" checklist of transferable techniques.

This skill is for synthesis and methodology, not for generating designs. If the user wants a design *built*, hand off to a frontend skill (e.g., `frontend-design`) afterward.

---

## When to use this skill

Trigger as soon as the user gives you 2+ design-reference URLs and an analytical or research goal. Examples:

- "Here are sites whose design I liked, do research on them and find similar ones."
- "What's the visual philosophy connecting these landing pages?"
- "I want to build a marketing site like X, Y, Z — break them down for me."
- "Find me more sites in the style of [reference]."
- "Audit these for inspiration / make me a moodboard."

Do NOT trigger for: a single URL with a narrow technical question (e.g., "how is this hero animated"), code-level reproduction requests (use a frontend skill), or unrelated web-research tasks.

---

## Workflow

### Step 1 — Confirm scope (one short turn, only if ambiguous)

If the goal is obvious from context, skip this step. Otherwise ask **one** short question:
- Are they researching to build a site, building a moodboard, or just curious about the lane?
- Any specific axis they care about (motion / typography / data viz / hardware narrative / etc.)?

Default if no answer: produce a full audit covering all axes.

### Step 2 — Fetch each URL

Use `web_fetch` on every URL the user provides. Many design-forward sites are SPA shells that return only a `<title>` and metadata on raw fetch. When that happens:
1. Try fetching `/about`, `/blog`, `/products/...`, sitemap, or a sub-page that's more SSR-rendered.
2. Run a `web_search` for the site's name + "review" or "design" to find third-party breakdowns.
3. Be honest in the final report — flag the site as "inferred" rather than fabricating specifics.

While fetching, capture:
- `<meta name="generator">` tag (often reveals Webflow, WordPress, etc.)
- Asset CDN domains (see `references/tech-stack-signatures.md`)
- Font files / `@font-face` URLs
- Linked JS bundles (Next.js `_next/`, Gatsby `static/`, GSAP, Lenis, Three.js, Framer Motion)
- Image format mix (AVIF, WebP, MP4 loops vs PNGs)
- Visible color palette + typography from any rendered text

### Step 3 — Per-site breakdown

For each site, produce this exact sub-structure:

```markdown
### N) <site> — <one-line positioning>
- **Design philosophy / identity:** <2-3 sentences. What movement does it belong to?>
- **Visual language:** <typography, color palette, mood, density>
- **Layout / patterns:** <hero treatment, section rhythm, recurring motifs, motion moments>
- **Steal-this:** <1-3 specific transferable techniques>
- **Tech indicators:** <stack guesses with CONFIRMED vs INFERRED labels>
```

Keep each site to ~150-250 words. If you don't have enough signal, say so and shrink the section — never invent details.

### Step 4 — Cluster into design movements

Group the set into 2-5 overlapping movements/philosophies. Use `references/design-movements.md` for the canonical clusters (AI-native enterprise minimalism, Apple-style premium hardware narrative, editorial data-storytelling, manifesto/coalition microsites, premium designer-developer education, brutalist editorial, kinetic-type / WebGL-heavy creative coding, bento-grid product launches, etc.). Coin a new cluster only if the set genuinely doesn't map onto an existing one.

### Step 5 — Find similar sites

For each cluster, list 6-15 cousin sites the user can study. Pull from:
1. The canonical lists in `references/design-movements.md`
2. Curated galleries in `references/curated-galleries.md` (Awwwards, Godly, Land-book, Lapa Ninja, SiteInspire, Httpster, Saaspo, Landingfolio, etc.)
3. GitHub awesome lists (`references/curated-galleries.md` enumerates them)
4. Web-search verification — confirm at least 2-3 of the recommended URLs are still live before finalizing the list.

### Step 6 — Cross-cutting themes

Surface 5-8 patterns that span multiple sites in the user's set (e.g., "animated MP4 product loops as hero", "dual-row infinite testimonial marquees", "warm accent on neutral canvas", "`llms.txt` + Markdown shadow page"). These are the highest-signal takeaways and should be called out separately from the per-site sections.

### Step 7 — "Steal-this" checklist

Produce 15-25 numbered, concrete, transferable techniques. Each item should be specific enough to act on (a designer / dev should know exactly what to build). See the example checklist in `assets/output-template.md`.

### Step 8 — Caveats

End with a short Caveats section listing:
- Sites where the homepage was an SPA shell and analysis is partly inferred
- Sites where tech-stack guesses are not confirmed
- Any sites that 404'd or returned blocked content
- Any site count mismatches between what was promised and what was delivered

Honesty here is non-negotiable — design audits lose all value when fabricated.

---

## Output format

Default: a single markdown artifact (`text/markdown` artifact, not inline prose). Use the structure in `assets/output-template.md`. The artifact is the deliverable; the inline chat reply should be a 2-4 sentence summary that points at the artifact.

If the user asked for something narrower (e.g., "just give me 5 similar sites to X"), skip the full audit and answer directly. The skill is a toolkit, not a forced template.

---

## Reference files

Read these on demand based on what the audit needs:

- `references/design-movements.md` — the canonical philosophy clusters with example "cousin" sites for each. Read this in Step 4 and Step 5.
- `references/curated-galleries.md` — Awwwards / Godly / Land-book / GitHub awesome lists / Medium articles / Smashing-Codrops / Webstacks. Read this in Step 5 and when the user asks for ongoing-discovery resources.
- `references/tech-stack-signatures.md` — how to fingerprint Webflow, Framer, Next.js, Gatsby, WordPress, custom React from URL patterns, meta tags, and asset CDNs. Read this during Step 2 when fetching.
- `references/codepen-creators.md` — creators and libraries to follow for specific techniques (WebGL hero, scrollytelling, marquees, gradient mesh, etc.). Read this when producing the Steal-this section.
- `assets/output-template.md` — the full markdown skeleton for the final artifact.

---

## Style guardrails

- **No filler.** Skip "I'd be happy to..." preambles. Open with the audit or a one-line summary, then the artifact.
- **Always web-fetch / web-search.** Never analyze a site from memory of its older design — sites get redesigned. The user's preference is verification-first.
- **Confirmed vs. Inferred labels.** Tag every tech-stack claim. "Webflow (confirmed via meta-generator)" vs. "Likely Next.js + Framer Motion (inferred from category convention)."
- **Don't over-format.** Bulleted lists where they help, prose where it reads better. No headers smaller than `###`.
- **Quote conservatively.** Stay under 15 words per quote, one quote per source maximum, paraphrase the rest. (This matches Claude's broader copyright posture.)
- **Don't pad to hit 25 steal-this items.** If 15 are real, 15 is the answer.

---

## Failure modes to avoid

1. **Fabricating visual details when fetch failed.** If the page returned an SPA shell, say so. Do not describe colors, fonts, or layouts you couldn't verify.
2. **Generic "they all use minimalism" takeaways.** Steal-this items must be specific (e.g., "dual-row testimonial marquee with `prefers-reduced-motion` fallback" not "good testimonials").
3. **Recommending dead sites.** Verify at least a sample of recommended cousins via search before finalizing.
4. **Forced clustering.** If the user's set genuinely doesn't share a philosophy, say "these don't form a cluster" — don't invent one to be tidy.
5. **Skipping the Caveats section.** Even a perfect audit needs explicit confidence labels.

---

## Quick reference — the 8-step flow

1. Confirm scope (skip if obvious)
2. Fetch each URL + capture stack signals
3. Per-site breakdown (philosophy / visual / patterns / steal / tech)
4. Cluster into design movements
5. Similar sites grouped by cluster
6. Cross-cutting themes
7. Steal-this checklist (15-25 items)
8. Caveats
