# Design Movements & Cousin Sites

Use this file in Step 4 (clustering) and Step 5 (similar sites). These are the canonical philosophy clusters that show up across modern web design references. Most user sets will map onto 2-4 of these.

If a cluster fits, list 6-15 cousin sites from the lane. If a user's set genuinely doesn't fit any cluster, coin a new one — but most sites do fit, so check here first.

---

## A. AI-native enterprise minimalism (Linear / Stripe / Vercel lineage)

**Aesthetic markers:** Light-or-dark canvas with generous whitespace, single warm-or-cool accent, animated chat / UI screenshots as hero, customer logo wall, alternating feature rows with looping MP4 product clips, glass trust cards, gradient-mesh final CTA.

**Differentiator inside cluster:** the accent color (Mistral cinnabar, Anthropic warm tan, Cohere pastel, Vercel monochrome+neon, etc.).

**Cousin sites:**
- https://anthropic.com — warm-tone AI minimalism, gold standard
- https://www.cursor.com — chat / code-editor product-as-hero
- https://linear.app — original "calm SaaS" template
- https://vercel.com — bento grids, glow borders, dark + accent
- https://www.cohere.com — pastel + neat AI sans
- https://www.perplexity.ai — chat hero with typewriter
- https://www.together.ai — dark + neon, technical
- https://www.deepgram.com — voice-AI, animated demos
- https://www.glean.com — Stripe-influenced enterprise AI
- https://www.notion.so/ai — chat-overlay product hero
- https://granola.ai — chat-bubble-as-hero
- https://magic.dev — minimalist agent product page
- https://www.harvey.ai — legal AI, near-Mistral discipline
- https://stripe.com — the lineage progenitor

---

## B. Brand-forward AI-agent storytelling

**Aesthetic markers:** Heavier brand identity than cluster A. Dark canvas with neon accents OR playful pastel. Bento-grid feature shelves with hover glow. UI mockups for every product surface. "v2.0 launch" cadence.

**Cousin sites:**
- https://elevenlabs.io — playful but premium AI brand
- https://www.suno.com — generative-music agent, bold
- https://www.runwayml.com — dense, motion-heavy
- https://www.captions.ai — AI agent for video creators
- https://relume.io — AI design agent landing
- https://www.lovable.dev — AI builder
- https://v0.dev — AI builder, bento-heavy
- https://bolt.new — AI builder
- https://www.figma.com/ai — AI features in incumbent product
- https://framer.com — AI design tool

---

## C. Apple-style premium hardware narrative

**Aesthetic markers:** Dark stages, edge-to-edge product photography, sticky-pinned scroll sections, numbered highlight nav, specs-as-typography, GSAP ScrollTrigger choreography, single product on a black backdrop, crossfaded MP4 frames.

**Cousin sites:**
- https://www.apple.com/airpods-pro/ — the source code of the genre
- https://rabbit.tech — agent + hardware crossover
- https://humane.com — Ai Pin (archival)
- https://teenage.engineering — extreme-minimal hardware
- https://nothing.tech — dot-matrix industrial brand
- https://framework.computer — hardware spec storytelling
- https://www.dji.com/osmo-pocket-3 — direct competitor energy
- https://www.beatsbydre.com/headphones/studio-pro — color-block dark hero
- https://www.insta360.com — full hardware product line
- https://www.gopro.com — sport hardware
- https://www.leica-camera.com — heritage hardware

---

## D. Editorial data-storytelling / annual-report-as-website

**Aesthetic markers:** Long-scroll narrative, embedded interactive D3 / Observable Plot charts, anchor-linked sections, globe or map intro, monospace for figures, large editorial display font, increasingly an `llms.txt` and Markdown shadow page.

**Cousin sites:**
- https://stripe.com/annual-updates/2025 — gold standard
- https://newsletter.pudding.cool / https://pudding.cool — long-form scrollytelling
- https://wrapped.spotify.com — annual ritual
- https://flowingdata.com — data viz tutorials
- https://observablehq.com — D3 / Plot showcases
- https://informationisbeautiful.net — editorial data
- https://stateofjs.com / https://stateofcss.com / https://stateof.ai — annual surveys
- https://www.gapminder.org — interactive global data
- https://ourworldindata.org — academic-flavored
- https://www.nytimes.com/interactive/ — NYT investigations
- https://www.washingtonpost.com/graphics/ — WaPo graphics desk

---

## E. Manifesto / coalition / policy microsites

**Aesthetic markers:** Editorial typography (often a contemporary serif), white canvas with one muted accent, evidence screenshots embedded as proof points, named pull-quotes, member-logo strip, civic register rather than commercial. Often built on WordPress by a comms agency.

**Cousin sites:**
- https://www.righttorepair.eu — closest analog (EU coalition)
- https://openweb.foundation
- https://www.fairvote.org
- https://stop-killer-robots.org
- https://www.protectyourdata.org
- https://www.eff.org — long-running digital rights
- https://www.themarkup.org — investigative tech journalism
- https://signaboveboard.org

---

## F. Premium designer / developer education

**Aesthetic markers:** Soft rounded cards, custom icon language (avoiding Phosphor / Lucide defaults), app-icon-style course tiles, "Lite mode" toggle, course thumbnails that mirror the actual UI being built, pricing inline in hero.

**Cousin sites:**
- https://designcode.io — long-running benchmark
- https://frontendmasters.com
- https://buildui.com — Sam Selikoff
- https://wesbos.com — Beginner JS, etc.
- https://www.joshwcomeau.com — CSS for JS Devs
- https://www.totaltypescript.com — Matt Pocock
- https://epicweb.dev — Kent C. Dodds
- https://www.boot.dev — dark-mode game-ified
- https://daily.dev — dev news, similar card system
- https://www.codecademy.com — large-scale benchmark
- https://laracasts.com — Laravel-focused
- https://www.executeprogram.com — interactive lessons

---

## G. Brutalist editorial / kinetic typography

**Aesthetic markers:** Unconventional grid breaks, oversized display type, raw HTML aesthetic, monospace mixed with display serifs, intentional ugliness or chaos, marquee tickers, color clashes.

**Cousin sites:**
- https://www.are.na
- https://www.theoutpostmag.com
- https://www.read.cv
- https://onyx.studio
- https://www.bracket.studio
- https://gmunk.com
- Most Awwwards SOTM winners in the "experimental" category

---

## H. WebGL-heavy / creative coding showcase

**Aesthetic markers:** Three.js / R3F driven heroes, fluid-simulation shaders, cursor-driven distortion, custom typography meshes, often portfolio sites for digital agencies or creative coders.

**Cousin sites:**
- https://lusion.co
- https://www.activetheory.net
- https://hello.monogrid.com
- https://immersive-g.com
- https://bonhomme.lol
- https://www.studiothomas.com
- https://anatomy.com
- https://14islands.com
- https://www.ueno.co
- Awwwards "Innovation" SOTM winners

---

## I. Bento-grid product launches (Vercel / Linear / v0 lineage)

**Aesthetic markers:** Variably-sized tiles in a bento grid, each tile showing a real product surface, hover glow borders, slight 3D tilt, dark canvas with neon accent. Used heavily for "v2.0" or major-feature launches.

**Cousin sites:**
- https://vercel.com (and any Vercel sub-product page)
- https://v0.dev
- https://linear.app/changelog
- https://cursor.com
- https://www.figma.com/ai
- https://www.notion.com/product
- https://www.raycast.com
- https://arc.net
- https://www.dia.so
- https://www.anthropic.com/claude (Anthropic uses a softer bento)

---

## J. Glassmorphism / Apple Vision Pro influence

**Aesthetic markers:** Frosted glass cards, depth-stacked translucent surfaces, soft gradient backgrounds bleeding through, squircle border-radius, depth via blur rather than shadow.

**Cousin sites:**
- https://www.apple.com/apple-vision-pro/
- https://www.raycast.com
- https://arc.net
- https://www.dia.so
- https://granola.ai
- https://www.cron.com (now Notion Calendar)
- https://www.amie.so
- https://www.mymind.com

---

## How to use this list

1. Read the user's set of references.
2. For each site, decide which 1-2 clusters above it belongs to.
3. In the report, cluster the user's set, then for each cluster recommend 6-12 cousins from this file.
4. Prioritize live sites — do a `web_search` to confirm any cousin you're unsure about before recommending it.
5. If the user's set spans 4+ clusters, keep recommendations tight (5-6 per cluster) to avoid overwhelm.
