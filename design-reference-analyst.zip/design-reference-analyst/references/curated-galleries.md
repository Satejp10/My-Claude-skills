# Curated Galleries, Awesome Lists & Articles

Use this file in Step 5 (similar sites) and when the user asks for ongoing-discovery resources.

These are the sources to mine for cousin sites, design trend coverage, and ongoing inspiration. Re-verify URLs are live with a web_search if you're recommending them in a final deliverable.

---

## Daily-feeder curated galleries

| Source | URL | Strength |
|---|---|---|
| Awwwards | https://www.awwwards.com | SOTD, SOTM, "AI Powered Web Projects" collection. Highest prestige. |
| Godly | https://godly.website | Boutique, very current, opinionated |
| Land-book | https://land-book.com | Clean SaaS-leaning, well-tagged |
| Lapa Ninja | https://www.lapa.ninja | Landing pages by category (AI category 198+) |
| SiteInspire | https://www.siteinspire.com | Refined editorial taste, lower volume |
| Httpster | https://httpster.net | Eclectic, less SaaS, more agency / studio |
| Saaspo | https://saaspo.com | SaaS-focused, e.g. `/industry/ai-saas-websites-inspiration` (200+) |
| Landingfolio | https://www.landingfolio.com | Components-first, 800+ component examples |
| CSS Design Awards | https://www.cssdesignawards.com | Awwwards alternative |
| One Page Love | https://onepagelove.com | Single-page sites |
| Mobbin | https://mobbin.com | App-pattern reference (paid, valuable for product pages) |
| Refero | https://refero.design | UI patterns from real apps |
| Page Flows | https://pageflows.com | User-flow recordings (paid) |

---

## GitHub awesome lists (verified handles)

- `terkelg/awesome-creative-coding` — canonical for WebGL / Three.js / p5.js / shaders / generative
- `rasagy/awesome-creative-coding-js-libraries` — deep cut: R3F, OGL, PixiJS, GSAP, Motion, Tone.js, ml5.js, Hydra
- `JessicaML/awesome-creative-coding` — alternate creative-coding curation
- `PaulleDemon/awesome-landing-pages` — open-source landing-page templates
- `nordicgiant2/awesome-landing-page` — practical templates
- `Edlavio/awesome-landing-pages` — modern marketing examples
- `creativetimofficial/awesome-landing-page` — Bootstrap-era but useful structure
- `jnettome/awesome-landing-page` — curated articles on landing-page craft
- `bradtraversy/design-resources-for-developers` — broad design-resource dump
- `niklasvh/awesome-web-typography` — typography-specific
- `sw-yx/spark-joy` — small touches and polish patterns

GitHub topic pages worth periodic checks:
- `design-inspiration`
- `landing-page-inspiration`
- `awesome-portfolios`
- `ui-design-resources`

---

## Articles & long-reads (publications, not specific posts)

- **Codrops** — `https://tympanus.net/codrops/` — Yuri Artiukh's case studies on shader / WebGL effects. Search by author.
- **Smashing Magazine** — modern CSS, scroll-driven animation, `@property`, dark-mode design, AI design pattern essays
- **CSS-Tricks** — archives still gold for layout, scroll, and pseudo-element technique
- **Webstacks blog** — `https://www.webstacks.com/blog` — strong "AI website examples" breakdowns
- **Eleken** — case studies on B2B SaaS UI, brand strategy
- **Figma resource library** — annual "Top Web Design Trends" lists
- **Hostinger / Elementor / Webflow blogs** — annual trend roundups (baseline reading)
- **Vercel / Linear / Stripe blogs** — first-party design-engineering essays
- **A List Apart** — long-form web design / IA / accessibility
- **Nielsen Norman Group** — usability research

---

## Tech-forward references for ongoing technique discovery

- **Awwwards "AI Powered Web Projects"** collection
- **Saaspo industry/ai-saas-websites-inspiration** — 200+ AI SaaS landing pages tagged
- **Vercel templates gallery** — `https://vercel.com/templates` — production-grade Next.js patterns
- **Cult UI / Magic UI / Aceternity UI / shadcn/ui** — component libraries that mirror current bento-grid patterns
- **Framer marketplace** — `https://www.framer.com/marketplace/` — premium templates show current Framer-native idioms
- **Webflow showcase** — `https://webflow.com/discover/popular` — same for Webflow

---

## How to use this list

When recommending similar sites in Step 5:
- Pull primarily from `design-movements.md` (cluster-mapped cousins)
- Use the galleries here for additional discovery if the user's set is unusual
- Do a final `web_search` pass to verify the top 5-10 recommendations are still live

When the user asks "where do I keep finding more sites in this style":
- Recommend 3-5 daily-feeder galleries (Awwwards + Godly + one specialist for their cluster)
- Recommend 1-2 GitHub awesome lists they can star
- Recommend 1-2 publications to subscribe to (Codrops + Smashing is a strong default pair)
