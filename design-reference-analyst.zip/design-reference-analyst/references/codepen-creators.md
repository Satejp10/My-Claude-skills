# CodePen Creators & Libraries by Technique

Use this file in Step 7 (Steal-this checklist) when recommending where the user can study a specific technique. Pair each recommended technique with a creator or library so the user has a concrete next step.

---

## Creators to follow on CodePen

| Creator | Handle / find by | Specialty |
|---|---|---|
| Yuri Artiukh | `@akella` | WebGL hero techniques, image distortion, sticky-scroll, Three.js shaders. Author of Codrops case studies on Tao Tajima, Crosswire, Midwam, Kenta Toshikura. |
| Manoela Ilic | `@crnacura` | Codrops co-founder. Grid layouts, page transitions, image-reveal effects. |
| Bruno Imbrizi | `@brunoimbrizi` | Generative art, particles, creative coding. |
| Inigo Quilez | `@iq` | Fragment shaders / SDFs. Best for gradient hero meshes and procedural backgrounds. |
| Hakim El Hattab | `@hakimel` | Clever DOM/SVG creative coding (creator of Reveal.js). |
| Cassie Evans | `@cassie-codes` | GSAP-driven SVG, accessibility-aware motion. GSAP team's go-to demo author. |
| George Francis | `@georgedoescode` | Generative SVG, friendly creative coding. Great for gradient-mesh patterns. |
| Tobias Reich | `@electerious` | UI micro-interactions. |
| Jhey Tompkins | `@jh3y` | Modern CSS, scroll-driven animations, `@property` magic, View Transitions API. |
| Ana Tudor | `@thebabydino` | CSS deep magic, math-driven layouts, single-element art. |
| Lynn Fisher | `@lynnandtonic` | Single-DIV CSS art, brand-quirky. |
| Adam Argyle | `@argyleink` | Modern CSS evangelism, Open Props, theming. |

---

## Pen patterns to search for

When the user asks about a specific pattern, search CodePen for these phrases and study the top results:

- "WebGL fluid hero" / "fluid simulation hero"
- "Sticky scroll image reveal" (Apple AirPods technique)
- "Bento grid hover glow" (Vercel / v0 style)
- "Marquee testimonials infinite" (with `prefers-reduced-motion` guards)
- "Scroll-driven animation @scroll-timeline" (modern CSS, no JS)
- "Three.js distortion image transition"
- "Globe Three.js" / "WebGL earth points" (Levels.fyi / GitHub style)
- "Lottie product hero" (Granola / Mistral style)
- "View Transitions API page transition"
- "@property gradient animation"
- "Text scramble effect" (kinetic type)
- "Magnetic cursor button"
- "3D card tilt hover" (vanilla-tilt or framer-motion)

---

## Libraries to recommend by category

### Animation orchestration
- **GSAP + ScrollTrigger** — `https://gsap.com` — single most-used animation tool across modern marketing sites. Free for most use cases as of 2024.
- **Framer Motion / Motion** — `https://motion.dev` — React-side animation, default for Next.js sites.
- **Anime.js** — `https://animejs.com` — lightweight, good for vanilla JS.

### Smooth scrolling
- **Lenis** — `https://lenis.darkroom.engineering` — buttery smooth-scroll, near-mandatory for premium feel
- **Locomotive Scroll** — older alternative, parallax-friendly

### 3D / WebGL
- **Three.js** — foundation
- **react-three-fiber + drei** — declarative R3F for 3D in React
- **OGL** — minimal WebGL when R3F is overkill
- **PixiJS** — 2D WebGL, useful for fluid sims and particle effects

### Vector animation
- **Lottie (lottie-react / lottie-web)** — for After Effects exports
- **Rive** — `https://rive.app` — interactive vector animations, increasingly used for AI product hero loops (better than Lottie for state-driven motion)

### Data visualization
- **D3.js** — foundation
- **Observable Plot** — higher-level, Levels.fyi-style charts
- **Visx** (Airbnb) — React + D3 hybrid
- **ECharts / Highcharts** — when you need batteries-included
- **deck.gl** — geospatial / large-scale data

### Type & layout
- **Open Props** — Adam Argyle's CSS variables
- **Tailwind CSS** — utility-first, dominant in AI-startup tier
- **shadcn/ui** — component recipes for Tailwind + Radix
- **Magic UI / Aceternity UI / Cult UI** — pre-built marketing-page components

### Generative art / creative coding
- **p5.js** — beginner-friendly creative coding
- **Hydra** — live-coded video synthesis
- **Tone.js** — audio synthesis
- **ml5.js** — friendly ML in the browser

---

## How to use this file

When you produce a Steal-this checklist item, pair it with a concrete next step:

> **Bento-grid feature shelf with hover glow** — see Vercel and v0.dev for production examples; Magic UI / Aceternity UI ship pre-built components; on CodePen search "bento grid hover glow" and study top pens.

Avoid recommending libraries the user clearly already knows (don't tell a senior frontend developer what GSAP is). Calibrate to the audience.
