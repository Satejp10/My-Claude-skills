# Output Template — Final Artifact Skeleton

Use this exact structure for the markdown artifact deliverable. Adjust headings and counts to fit the user's set, but keep the section order. Default artifact title format: `Design Inspiration Audit: <descriptor>`.

---

```markdown
# Design Inspiration Audit: <N> Reference Sites and Cross-Cutting Themes

> Optional one-line note on caveats (e.g., "Two sites returned SPA shells on fetch; analysis flagged in Caveats").

---

## TL;DR

- (3-5 bullets capturing the most important takeaways: the dominant philosophies, common tech-stack signals, and the highest-leverage steal-this patterns.)

---

## Key Findings — Per-Site Breakdown

### 1) <site> — <one-line positioning>
- **Design philosophy / identity:** ...
- **Visual language:** ...
- **Layout / patterns:** ...
- **Steal-this:** ...
- **Tech indicators:** ... (label CONFIRMED vs INFERRED)

### 2) <site> — <one-line positioning>
... (repeat for each site in user's set)

---

## Cross-Cutting Themes & Design Movements

(5-8 numbered themes that span multiple sites in the set. Each theme: 1-3 sentences. These are higher-signal than per-site findings.)

1. **<Theme name>.** Sites in the set that exemplify it: <list>. Why it matters: <1 sentence>.

---

## Similar Sites to Study, Grouped by Philosophy Cluster

### A. <Cluster name> (cousins of <user-set sites that fit this cluster>)
- https://example1.com — short tag
- https://example2.com — short tag
- ... (6-15 cousins)

### B. <Cluster name>
... (repeat for each cluster the user's set spans)

---

## GitHub Repos, Curated Galleries & Articles to Keep Discovering

**GitHub awesome lists:**
- `terkelg/awesome-creative-coding`
- ...

**Curated galleries (the daily-feeders):**
- https://www.awwwards.com
- ...

**Articles & long-reads worth bookmarking:**
- Codrops — case studies on shader / WebGL effects
- ...

---

## CodePen Examples & Creators to Follow

**Creators:**
- **<creator>** — specialty
- ...

**Pen patterns to search for:**
- "..."
- ...

**Frameworks/libraries to study:**
- **<library>** — what it's for
- ...

---

## "Steal This" Checklist

(15-25 numbered, concrete, transferable techniques. Each item: 1-2 sentences. Specific enough that a designer or developer knows exactly what to build.)

1. **<Technique name>** — concrete description with reference site (e.g., "Replace static hero screenshots with 200-500KB MP4 product loops; see Nume, YourGPT, and Mistral").
2. **<Technique name>** — ...
3. ...

---

## Caveats

- Sites that returned SPA shells / 404s and were partly inferred: <list>
- Tech-stack claims that are inferred rather than confirmed: <list>
- Site-count or scope mismatches between brief and deliverable: <list>
- Anything else worth flagging for honesty
```

---

## Notes on filling the template

- **TL;DR** is the only "marketing copy" section. Keep it under 5 bullets.
- **Per-site breakdowns** are 150-250 words each. Don't pad.
- **Cluster groupings** should match how the sites *actually* relate, not how they look superficially. A SaaS site with editorial typography and a coalition site with editorial typography are not the same cluster.
- **Steal-this items** are specific. "Use good typography" is not a steal-this; "Pair a humanist body sans (Inter / Söhne) with a single display serif for section openers, monospace for metrics — three voices per page max" is.
- **Caveats** end the artifact. Even a perfect audit has caveats. If you can't find any, you probably weren't honest enough about confidence.
