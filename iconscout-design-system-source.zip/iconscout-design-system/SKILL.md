---
name: iconscout-design-system
description: Apply the Iconscout design system (clean B2B marketplace aesthetic — blue/teal palette, Averta typography, 4px grid, subtle layered shadows, generous whitespace) when generating any HTML, CSS, React, or Tailwind UI. Use this skill whenever the user references "Iconscout style", asks for a "clean SaaS / marketplace look", asks for a "B2B product page", asks to "match Iconscout", or pastes any reference to iconscout.com. ALSO use when generating landing pages, product pages, dashboards, settings UIs, or portfolios where a professional-but-approachable marketplace aesthetic fits — even if the user doesn't say "Iconscout" by name. Default to this aesthetic for clean B2B SaaS work; do NOT use it for editorial, brutalist, maximalist, dark-mode, or playful/toy designs (those need a different aesthetic direction).
---

# Iconscout Design System

A faithful implementation of the Iconscout marketplace aesthetic: clean, professional, approachable, modern-tech. Spacious and organized, bright but restrained, with subtle layered shadows lifting white cards off a near-white background.

**Core feel:** "Stripe meets Notion meets a well-run B2B SaaS marketplace." Trustworthy, scannable, optimistic, never flashy.

---

## When to use this skill

Use this skill when generating:
- Landing pages, marketing pages, product pages, pricing pages
- Dashboards, settings panels, admin UIs
- Onboarding flows, sign-up pages, empty states
- Portfolio sites and PM/designer/eng personal sites that need to feel professional and recruiter-ready
- Any "B2B SaaS marketplace" UI

**Do NOT use this skill for:** editorial/magazine designs, brutalist or maximalist work, dark mode by default, retro/vaporwave/y2k, consumer playful (Duolingo/Notion-doodle style), luxury/refined high-contrast, or anything where the aesthetic call is "make it feel like art." Those need a different direction.

If the user has uploaded their own design system or design tokens, **those win** — don't override them with these tokens.

---

## Required first step

Before generating any component or page, read `references/DESIGN.md` for the full philosophy and `references/design_tokens.json` for canonical values. The CSS variables in `references/css_variables.css` and the Tailwind v4 theme in `references/tailwind_v4.css` are paste-ready — use them as-is, do not transform or rename.

For a complete worked example showing every component pattern in context, see `assets/example-portfolio.html`.

---

## Design tokens (canonical)

### Colors
| Token | Hex | Use for |
|---|---|---|
| `--color-primary-blue` | `#2479ff` | Primary CTAs, links, brand accents, focused states |
| `--color-dark-text` | `#1c2033` | Primary text, headings |
| `--color-secondary-gray` | `#596080` | Secondary text, meta, captions, muted labels |
| `--color-success-teal` | `#24a8af` | Success states, "open / active" indicators |
| `--color-warning-yellow` | `#e7b549` | Warning states, attention pills |
| `--color-pure-white` | `#ffffff` | Card surfaces, primary background |
| `--color-light-background` | `#fafafc` | Section backgrounds, app shells |
| `--color-border-gray` | `#ebedf5` | Dividers, card borders, input outlines |

### Typography
- **Family:** Averta only. No second family. If Averta isn't licensed, use stack: `'Averta', 'DM Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`. DM Sans is the closest free Google Font.
- **Weights:** 400 (body), 500 (labels/buttons/nav), 700 (headings). No other weights.
- **Sizes:** 12 / 14 / 16 / 20 px (token scale). Headings can scale up via `clamp()` for hero text, but the *system* sizes are these four.
- **Line heights:** 16 (small) / 24 (body, label, button) / 28 (heading).
- **Letter spacing:** normal. Tighten to `-0.01em` to `-0.02em` only on display-size headings (40px+).

### Spacing (4px base grid)
`4 / 8 / 12 / 16 / 24 / 32 / 40 / 48` — tokens `xs / sm / md / lg / xl / 2xl / 3xl / 4xl`. Never use spacing values outside this scale.

### Border radius
`4 / 6 / 8 / 12 / 16 / 50` — tokens `sm / md / lg / xl / 2xl / full`. The pill (`50px`) is for buttons and status badges only. Cards default to `xl` (12px) or `2xl` (16px). Inputs use `lg` (8px).

### Elevation
Use layered shadows, never single drop-shadows. Recommended scale:
```css
--shadow-sm:    0 1px 2px rgba(28, 32, 51, 0.06);
--shadow-md:    0 2px 4px rgba(28, 32, 51, 0.06), 0 4px 12px rgba(28, 32, 51, 0.06);
--shadow-lg:    0 4px 8px rgba(28, 32, 51, 0.06), 0 12px 28px rgba(28, 32, 51, 0.08);
--shadow-hover: 0 8px 16px rgba(28, 32, 51, 0.08), 0 20px 40px rgba(36, 121, 255, 0.08);
```
The hover shadow gets a faint blue tint — that's intentional, it's the brand peeking through.

---

## Layout rules

- **Max-width container:** `1120px` centered, with `24px` horizontal padding. Use `1200px` only for marketing-heavy hero pages.
- **Section padding:** `88px` top/bottom on desktop, `56–64px` on mobile.
- **Whitespace is the design.** When in doubt, increase padding before adding visual weight. Iconscout's "spaciousness" is the differentiator vs. dense dashboards.
- **Section rhythm:** alternate `--color-pure-white` and `--color-light-background` between sections to create gentle horizontal banding without using borders or dividers everywhere.

---

## Component patterns

### Primary button
```html
<a class="btn-primary" href="...">Get started</a>
```
```css
.btn-primary {
  background: var(--color-primary-blue);
  color: var(--color-pure-white);
  font-weight: 500;
  font-size: 16px;
  line-height: 24px;
  padding: 12px 24px;
  border-radius: var(--radius-full);
  box-shadow: var(--shadow-sm);
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}
.btn-primary:hover { background: #1a5fd8; transform: translateY(-1px); box-shadow: var(--shadow-md); }
```

### Ghost / secondary button
White background, dark text, gray border. Same shape as primary.

### Card
- Background `--color-pure-white`
- Border `1px solid var(--color-border-gray)`
- Radius `var(--radius-2xl)` (16px) — or `--radius-xl` (12px) for tighter cards
- Padding `var(--spacing-2xl)` (32px) for content cards; `var(--spacing-xl)` (24px) for compact
- Hover: `translateY(-2px)`, swap shadow to `--shadow-hover`, optionally tint border `rgba(36, 121, 255, 0.25)`

### Tag / pill
- Background `var(--color-light-background)`, border `1px solid var(--color-border-gray)`
- Padding `4px 12px`, radius `var(--radius-full)`, font-size 12px, font-weight 500
- Color variants: primary (`rgba(36, 121, 255, 0.08)` bg, blue text), teal, yellow — always at ~8–10% opacity background with full-saturation text

### Status badge
Pill shape with a small colored dot. Teal for "active / open / online", yellow for "pending / warning", blue for "info". Add subtle pulse on the dot for live indicators (`@keyframes pulse` with expanding box-shadow ring).

### Input
- Background `--color-pure-white`
- Border `1px solid var(--color-border-gray)`, focus border `--color-primary-blue` with `box-shadow: 0 0 0 4px rgba(36, 121, 255, 0.12)`
- Radius `var(--radius-lg)` (8px), padding `12px 16px`
- Placeholder color `--color-secondary-gray`

### Navigation
Sticky top, white at 85% opacity with `backdrop-filter: blur(12px)`. Bottom border `1px solid var(--color-border-gray)`. Nav links use Label Medium (14px / 500), color `--color-secondary-gray`, hover `--color-dark-text`. Always include a pill-shaped primary CTA on the right.

### Hero
- White background with two faint radial gradients (blue at 5% opacity top-left, teal at 5% opacity top-right) for atmosphere — never solid color, never busy.
- H1 at `clamp(40px, 7vw, 72px)`, weight 700, letter-spacing `-0.02em`.
- Lede paragraph at 20px / 32px line-height, color `--color-dark-text` with secondary-gray on supporting clauses. Max-width 640px.
- Status pill above the heading, meta-grid below.

---

## Do's

- Do use the 4px grid for every dimension. No `7px`, `13px`, `22px`.
- Do alternate white and `#fafafc` between sections for rhythm.
- Do use subtle layered shadows — multiple low-alpha layers, never one heavy drop shadow.
- Do use the pill radius (50px) exclusively for buttons and badges. Never on cards.
- Do use all four accent colors purposefully across a page: blue for action, teal for status/success, yellow for attention, neutral grays for everything else.
- Do prefer hover-lift (`translateY(-1px)` or `-2px`) + shadow swap as the default interaction. Avoid scale transforms.

## Don'ts

- Don't introduce a second font family. The system is single-family on purpose.
- Don't add gradients beyond the optional 5% radial atmosphere in heroes. No vibrant gradient buttons, no gradient text.
- Don't use border radius values outside the 4–16px scale (plus 50px pill). No `20px`, no `24px` on cards.
- Don't use heavy shadows (`rgba(0,0,0,0.2)` and above). Cap at `rgba(28,32,51,0.08)` for normal states.
- Don't use dark mode by default. If a dark variant is required, invert the surface tokens but keep blue and teal saturation — do not desaturate them.
- Don't use Inter, Roboto, or system-ui without an Averta primary in the stack. Pure system fonts will look like every generic AI-generated page.
- Don't use emoji as iconography. Use Lucide, Phosphor, or Iconscout's own line-icon set.

---

## Tailwind v4 usage

For projects using Tailwind v4, drop `references/tailwind_v4.css` into the entry CSS — it registers all tokens under `@theme` so Tailwind utilities like `bg-primary-blue`, `text-dark-text`, `p-xl`, `rounded-2xl` map directly to the system. No additional config needed.

For non-Tailwind projects, use `references/css_variables.css` and reference vars directly.

---

## Worked example

`assets/example-portfolio.html` is a complete single-file personal portfolio implementing every pattern above — hero with status pill, alternating section backgrounds, case-study card grid with hover-lift, status manifesto, experiments grid, contact strip, and footer. Read it when you need to see how the patterns compose into a full page. It is the canonical reference implementation.

---

## Failure modes to self-check

Before delivering output, verify:
1. Is every color one of the eight tokens, or a documented low-alpha variant of one?
2. Is every spacing value on the 4px grid?
3. Is the font stack Averta-first?
4. Are shadows layered, low-alpha, not single?
5. Are buttons and badges the only things with `border-radius: 50px`?
6. Does the page have a status indicator somewhere (the teal pulsing dot is a signature move)?
7. Are sections alternating white and `#fafafc`?

If any answer is "no", revise before presenting.
