## Overview

Clean, professional, and approachable with a modern tech aesthetic. The design feels spacious and organized, using bright cyan backgrounds and subtle shadows to create a welcoming yet sophisticated marketplace experience. The overall density is moderate, allowing content to breathe while maintaining efficient use of space.

The layout uses a centered max-width container system with generous whitespace. Content is organized in clear sections with consistent vertical rhythm. The hero section spans full width with a bright cyan background, while content below uses card-based layouts with consistent spacing. Grid systems are employed for feature showcases with equal-width columns.

Uses a 4px base grid with scale: 1, 2, 3, 4, 6, 8, 10, 12.

## Colors
- **Primary Blue** (#2479ff): Primary buttons, links, and brand accents
- **Dark Text** (#1c2033): Primary text content and headings
- **Secondary Gray** (#596080): Secondary text and subtle UI elements
- **Success Teal** (#24a8af): Success states and positive actions
- **Pure White** (#ffffff): Primary background and card surfaces
- **Light Background** (#fafafc): Secondary background areas
- **Border Gray** (#ebedf5): Subtle borders and dividers
- **Warning Yellow** (#e7b549): Warning states and attention-grabbing elements

## Typography
- **Headline Font**: Averta
- **Body Font**: Averta
- **Label Font**: Averta

The typography system relies exclusively on the Averta font family across all contexts, creating a cohesive and unified voice. Weight conventions follow a clear hierarchy: 700 for prominent headings, 500 for labels and navigation, and 400 for body text. Size relationships maintain consistent scaling with 20px headings, 16px body text, and 14px labels. Letter-spacing remains normal throughout, emphasizing readability over stylistic flourishes. The font choices create hierarchy through weight and size variations rather than family changes, resulting in a clean, professional appearance.

## Elevation

Depth is primarily conveyed through subtle layered shadows (rgba(0, 0, 0, 0.08) with multiple layers) rather than dramatic elevation changes. Cards and interactive elements use gentle shadow combinations to lift content off the background. The design avoids heavy shadows in favor of clean, minimal depth cues that maintain the professional aesthetic.

## Components
- **Primary Button**: Blue background buttons with white text, medium border radius, and subtle shadows
- **Card Container**: White background cards with subtle shadows and rounded corners for content grouping
- **Search Input**: Large search input with rounded corners and placeholder text styling
- **Navigation Menu**: Horizontal navigation with medium-weight text and hover states
- **Feature Grid**: Grid layout for showcasing different product categories with icons and descriptions
- **Hero Section**: Large hero area with gradient background and centered content layout

## Do's and Don'ts
- Do use the 4px spacing base unit for consistent rhythm throughout layouts
- Do maintain the subtle shadow system for depth without overwhelming the clean aesthetic
- Don't use border radius values outside the established 4-16px range for consistency
- Do leverage the Averta font weight hierarchy (400/500/700) for clear information architecture
- Don't introduce additional font families that would break the unified typographic voice
- Do use the established blue (#2479FF) for all primary actions and brand elements
- Don't use high-contrast shadows or dramatic elevation that conflicts with the minimal approach
- Do maintain generous whitespace to preserve the clean, professional appearance
